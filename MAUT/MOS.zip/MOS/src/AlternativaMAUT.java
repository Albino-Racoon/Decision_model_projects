import java.util.ArrayList;

public class AlternativaMAUT {
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int[] getVnos() {
        return vnos;
    }

    public void setVnos(int vnos) {
        for(int i=0;i<this.vnos.length;i++){
            if(this.vnos[i]==0){
                this.vnos[i] = vnos;
                break;
            }
        }

    }

    public void setVnos(int[] vnos) {
        this.vnos = vnos;
    }

    public AlternativaMAUT(String naziv) {
        this.naziv = naziv;
    this.vnos= new int[9];
        //  for(int i=0;i<vnos.length;i++){
        //    vnos[i]=0;
    //    }
    }

    public String naziv;
    public int[] vnos;

    public ArrayList<Integer> getVnosi() {
        System.out.println(vnosi);
        return vnosi;
    }

    public void setVnosi(ArrayList<Integer> vnosi) {
        this.vnosi = vnosi;
    }
public static int countAA=0;
    public ArrayList<Integer> vnosi;
}
