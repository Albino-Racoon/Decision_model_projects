import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.action.ActionButton;

import javax.swing.*;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class KTM {
    public static void main(String[] args) {
        JTextArea j = new JTextArea();
        JFrame frame = new JFrame("KTM Graf");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000,1000);
        frame.setVisible(true);

        frame.setLayout(new GridLayout(2,1));
        JTabbedPane tab=new JTabbedPane();

        frame.add(tab);



         JPanel Parametri=new JPanel();
        Parametri.setLayout(new GridLayout(3,1));
        JTextField Parameter_naziv=new JTextField();

        Parameter_naziv.setSize(50,25);

        JTextField Parameter_Utez=new JTextField();
        Parameter_Utez.setSize(50,25);

        JButton Dodaj_Parameter=new JButton("Dodaj parameter");
        Parametri.add(new JLabel("naziv"));
        Parametri.add(Parameter_naziv);
        Parametri.add(new JLabel("utez"));
       Parametri.add(Parameter_Utez);

        Parametri.add(Dodaj_Parameter);
        JButton koncaj=new JButton("Končaj");
Parametri.add(koncaj);



        ArrayList<Parameter> poljeParameter = new ArrayList<Parameter>();
        ArrayList<Alternativa> poljeAlternativa = new ArrayList<Alternativa>();
        Dodaj_Parameter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String ime = Parameter_naziv.getText();
                int utez = Integer.parseInt(Parameter_Utez.getText());

                poljeParameter.add(new Parameter((int) utez,(String) ime));
                Parameter[] par=new Parameter[poljeParameter.size()];

                for(int i=0;i<poljeParameter.size();i++){
                    par[i]=poljeParameter.get(i);
                }
                System.out.println(Arrays.toString(par));

            }

        });
        koncaj.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JPanel Alternativa=new JPanel();
                Alternativa.setLayout(new GridLayout(1,poljeParameter.size()));
                JTextField Alternative_naziv=new JTextField();
                JLabel naziv=new JLabel("alternativa naziv");
                Alternativa.add(naziv);
                Alternativa.add(Alternative_naziv);
                JTextField a1=new JTextField();
                JTextField a2=new JTextField();
                JTextField a3=new JTextField();
                JTextField a4=new JTextField();
                JTextField a5=new JTextField();
                JTextField a6=new JTextField();
                JTextField a7=new JTextField();
                JTextField a8=new JTextField();
                JTextField a9=new JTextField();
                JTextField a10=new JTextField();




                for (int i=0;i<poljeParameter.size();i++){

                    Alternativa.add(new JLabel(poljeParameter.get(i).naziv));
                    if(i==0) {
                        Alternativa.add(a1);
                    }
                    if(i==1) {
                        Alternativa.add(a2);
                    }
                    if(i==2) {
                        Alternativa.add(a3);
                    } if(i==3) {
                        Alternativa.add(a4);
                    } if(i==4) {
                        Alternativa.add(a5);
                    }
                    if(i==5) {
                        Alternativa.add(a6);
                    }
                    if(i==6) {
                        Alternativa.add(a7);
                    }
                    if(i==7) {
                        Alternativa.add(a8);
                    } if(i==8) {
                        Alternativa.add(a9);
                    } if(i==9) {
                        Alternativa.add(a10);
                    }






                    }
                final int[] count = {0};
                JButton dodaj_alternativo=new JButton("Dodaj alternativo");
                Alternativa.add(dodaj_alternativo);
                tab.addTab("Alternative",Alternativa);
                dodaj_alternativo.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        String ime = Alternative_naziv.getText();
                        int vrednost = Integer.parseInt(a1.getText());
                        poljeAlternativa.add(new Alternativa(ime,poljeParameter.size()));

                       // poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                      //  System.out.println("tu sm");
                        int idfk =poljeParameter.size();

System.out.println(idfk);
                        if(idfk>0) {
                             vrednost = Integer.parseInt(a1.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);

                        }
                        if(idfk>1) {
                            vrednost = Integer.parseInt(a2.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);

                        }
                        if(idfk>2) {
                            vrednost = Integer.parseInt(a3.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);

                        }
                        if(idfk>3) {
                            vrednost = Integer.parseInt(a4.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);

                        }
                        if(idfk>4) {
                            vrednost = Integer.parseInt(a5.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                        }
                        if(idfk>5) {
                            vrednost = Integer.parseInt(a6.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                        }
                        if(idfk>6) {
                            vrednost = Integer.parseInt(a7.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                        }
                        if(idfk>7) {
                            vrednost = Integer.parseInt(a8.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                        }
                        if(idfk>8) {
                            vrednost = Integer.parseInt(a9.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                        }
                        if(idfk>9) {
                            vrednost = Integer.parseInt(a10.getText());
                            poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                        }


                        count[0]++;
                        System.out.println("izpis counta         "+ count[0]);
                        }



                });

            }


        });




        tab.addTab("Parametri",Parametri);


        JPanel kkk=new JPanel();
        JButton graf_gumb=new JButton("Izrisi graf");
        kkk.add(graf_gumb);
        graf_gumb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(poljeParameter);
                System.out.println(poljeAlternativa);
                String[] parameter_naziv=new String[poljeParameter.size()];
                int[] parameter_utez=new int[poljeParameter.size()];
                String[] alternativa_naziv=new String[poljeAlternativa.size()];

                for (int i=0;i<poljeParameter.size();i++){
                    parameter_naziv[i]=poljeParameter.get(i).getNaziv();
                    parameter_utez[i]=poljeParameter.get(i).utez;

                }

                int[][] alternativa_vrednost=new int[poljeAlternativa.size()][poljeParameter.size()];
                JPanel rezultati=new JPanel();
                rezultati.setLayout(new FlowLayout());
                JTextArea izpis=new JTextArea();
                for (int i=0;i< poljeAlternativa.size();i++){
                    alternativa_naziv[i]=poljeAlternativa.get(i).getAlternativa_naziv();
                    alternativa_vrednost[i]=poljeAlternativa.get(i).vrednosti;
                    System.out.println(Arrays.toString(alternativa_vrednost[i]));
                    izpis.append(alternativa_naziv[i]);
                    izpis.append(Arrays.toString(alternativa_vrednost[i]));
                    }

int[] rez= new int[poljeAlternativa.size()];
                DefaultPieDataset pieDataset = new DefaultPieDataset();
                DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                for(int i=0;i<rez.length;i++){
rez[i]=0;
                    for(int t=0;t<poljeParameter.size();t++){
                       rez[i]= rez[i]+parameter_utez[t]*alternativa_vrednost[i][t];
                        System.out.println(String.valueOf(rez[i]));
                    }

                }
                for (int i=0;i< parameter_utez.length;i++){
                    pieDataset.setValue(   parameter_naziv[i], parameter_utez[i]);
                }
                int max=1;
                String max_naziv="...";
                for(int i=0;i<rez.length;i++){
                    izpis.append("“\n”");
                    System.out.println("REZULTAT: "+(i)+" JE: "+rez[i]+" in se nanasa na "+alternativa_naziv[i]);
                    izpis.append("“\n”");
                    izpis.append("REZULTAT: "+(i)+" JE: "+rez[i]+" in se nanasa na "+alternativa_naziv[i]);
                    izpis.append("“\n”");

                    dataset.setValue(rez[i], "", alternativa_naziv[i]);
                    if(rez[i]>max){
                        max=rez[i];
                        max_naziv=alternativa_naziv[i];
                    }

                }
System.out.println("najbolša odločiteu je: "+max_naziv+" z vrednosjo "+max);
                izpis.append("najbolša odločiteu je: "+max_naziv+" z vrednosjo "+max);


                JButton zaht_del=new JButton("Zahtevnejši del");
                rezultati.add(zaht_del);


                JFreeChart BARCHART = ChartFactory.createBarChart("Primerjava vrednosti",
                        "alternativa", "vrednost", dataset, PlotOrientation.VERTICAL,
                        false, true, false);



                JFreeChart chart = ChartFactory.createPieChart
                        ("utezi", // Title
                                pieDataset, // Dataset
                                true, // Show legend
                                true, // Use tooltips
                                false // Configure chart to generate URLs?
                        );


               /* izpis.append(String.valueOf(poljeParameter));
                izpis.append("“\\r\\n”");
                izpis.append(String.valueOf(poljeAlternativa));
*/
                rezultati.add(izpis);
                ChartPanel c=new ChartPanel(chart);
                ChartPanel cc=new ChartPanel(BARCHART);
                rezultati.add(c);
                rezultati.add(cc);

zaht_del.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        JPanel zd= new JPanel();
        zd.setLayout(new GridLayout(2,1));
       JList<Parameter> l=new JList<>();
        DefaultListModel<String> l2 = new DefaultListModel<>();
JButton button=new JButton("Analiza");


        for(int i=0;i< parameter_utez.length;i++){
       l2.addElement(parameter_naziv[i]);
        }
        JList<String> list2 = new JList<>(l2);
        zd.add(list2);
        zd.add(button);
button.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int z= list2.getSelectedIndex();
         JPanel graf =new JPanel();




        // Add the series to your data set
/*
if(z==0) {
    XYSeries series = null;
    for (int i = 0; i < poljeAlternativa.size(); i++) {
        series = new XYSeries(alternativa_naziv[i]);
        int vrednost = 0;
        for (int t = 1; t < parameter_utez.length; t++) {
            vrednost = vrednost + alternativa_vrednost[i][t] * parameter_utez[t];
        }
        for (int o = 0; 0 <= 10; o++) {
            series.add(o, alternativa_vrednost[i][z] * o + vrednost);
        }
    }
    dataset.addSeries(series);
}
if(z==parameter_utez.length-1) {
    XYSeries series = null;
    for (int i = 0; i < poljeAlternativa.size(); i++) {
        series = new XYSeries(alternativa_naziv[i]);
        int vrednost = 0;
        for (int t = parameter_utez.length - 2; t > 0; t--) {
            vrednost = vrednost + alternativa_vrednost[i][t] * parameter_utez[t];
        }
        for (int o = 0; 0 <= 10; o++) {
            series.add(o, alternativa_vrednost[i][z] * o + vrednost);
        }
    }
    dataset.addSeries(series);
}

    XYSeries series = null;
    for (int i = 0; i < poljeAlternativa.size(); i++) {
        series = new XYSeries(alternativa_naziv[i]);
        int vrednost1 = 0;
        int vrednost2 = 0;
        for (int t = 0; t < z; t++) {
            vrednost1 = vrednost1 + alternativa_vrednost[i][t] * parameter_utez[t];
        }
        for (int t = parameter_utez.length - 1; t >= z; t--) {
            vrednost2 = vrednost2 + alternativa_vrednost[i][t] * parameter_utez[t];
        }
        for (int o = 0; 0 <= 10; o++) {
            series.add(o, alternativa_vrednost[z][i] * o + vrednost1 + vrednost2);
        }

    }*/


        XYSeriesCollection dataset = new XYSeriesCollection();
        int[] rez= new int[poljeAlternativa.size()];
XYSeries[] ser= new XYSeries[rez.length];
        for(int i=0;i<rez.length;i++){
            XYSeries series = new XYSeries(alternativa_naziv[i]);
            ser[i]=series;
            dataset.addSeries(series);}

        for(int i=0;i<rez.length;i++){

            rez[i]=0;
            for(int t=0;t<poljeParameter.size();t++){
                if(t==z){
                    break;
                }
                rez[i]= rez[i]+parameter_utez[t]*alternativa_vrednost[i][t];
                System.out.println(String.valueOf(rez[i]));
            }

            for(int a = 0; a<rez.length; a++){

                for(int o=0;o<=10;o++){
//if(rez[a]<)
                    rez[a]= rez[a]+o*alternativa_vrednost[a][z];
                    ser[i].add(o,rez[a]);
                    System.out.println("DODANA VREDNOST: "+rez[a]);
                }
                rez[a]=0;
            }


        }











        // Generate the graph
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Analiza utezi ", // Title
                "od 0 do 10", // x-axis Label
                "vrednost", // y-axis Label
                dataset, // Dataset
                PlotOrientation.VERTICAL, // Plot Orientation
                true, // Show Legend
                true, // Use tooltips
                false // Configure chart to generate URLs?
        );
        ChartPanel ccc=new ChartPanel(chart);
        graf.add(ccc);
         tab.addTab("Graf2",graf);
    }
});
        tab.addTab("zahtevnejši del", zd);
    }
});
                tab.addTab("rezultati", rezultati);

            }
        });
tab.addTab("neki neki",kkk);








        frame.add(j);



    }
}
