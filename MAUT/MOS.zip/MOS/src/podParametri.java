public class podParametri {
    public parametri getNadredni() {
        return nadredni;
    }

    public void setNadredni(parametri nadredni) {
        this.nadredni = nadredni;
    }

    public int getUtez() {
        return utez;
    }

    public void setUtez(int utez) {
        this.utez = utez;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public Funkcija getFz() {
        return fz;
    }

    public void setFz(Funkcija fz) {
        this.fz = fz;
    }

    public podParametri( int utez, String naziv, int min, int max, Funkcija fz) {

        this.utez = utez;
        this.naziv = naziv;
        this.min = min;
        this.max = max;
        this.fz = fz;
        counter++;
    }

    public float funkcija(int min, int max, Funkcija f, int vrednost) {
        if(vrednost>max){
            return 0;
        }
        if(vrednost<min){
            return 0;
        }
        float nazaj=0;
        if(f.equals(Funkcija.LINEARNA)){
            nazaj=(max-vrednost)/10;
            return nazaj;
        }
        if(f.equals(Funkcija.EKSPONENTNA)){
            nazaj=(max-vrednost)/10;
            return nazaj;
        }
        if(f.equals(Funkcija.LOG)){
            nazaj=(max-vrednost)/10;
            return nazaj;
        }

        return 0;
    }

    public parametri nadredni;
    public int utez;
    public String naziv;
    public int min;
    public int max;
    public Funkcija fz;
    public static int counter;

}
