import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class MAUT {
    public static void main(String[] args) {
        final int[] countPP = {0};
            JTextArea j = new JTextArea();
            JFrame frame = new JFrame("MAUT");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1000,1000);
            frame.setVisible(true);

            frame.setLayout(new GridLayout(2,1));
            JTabbedPane tab=new JTabbedPane();

            frame.add(tab);

        JList seznamP =new JList<>();
        ArrayList<parametri> poljeParameter = new ArrayList<parametri>();
        ArrayList<podParametri> poljePODParameter = new ArrayList<podParametri>();
        ArrayList<Alternativa> poljeAlternativa = new ArrayList<Alternativa>();
            JPanel Parametri=new JPanel();
            Parametri.setLayout(new GridLayout(3,1));
            JTextField Parameter_naziv=new JTextField();

            Parameter_naziv.setSize(50,25);

            JTextField Parameter_Utez=new JTextField();
            Parameter_Utez.setSize(50,25);

            JButton Dodaj_Parameter=new JButton("Dodaj parameter");
            Parametri.add(new JLabel("naziv"));
            Parametri.add(Parameter_naziv);
            Parametri.add(new JLabel("utez"));
            Parametri.add(Parameter_Utez);



            Parametri.add(Dodaj_Parameter);
            JButton koncaj=new JButton("Končaj");
            Parametri.add(koncaj);
        Dodaj_Parameter.addActionListener(new ActionListener() {
      @Override public void actionPerformed(ActionEvent e) {

          poljeParameter.add( new parametri(Integer.parseInt(Parameter_Utez.getText()),Parameter_naziv.getText()));
          for(int i=0;i<poljeParameter.size();i++){
              System.out.println(poljeParameter.get(i));

          }
          poljeParameter.toArray().toString();
      System.out.println(poljeParameter);}
                                             });

        koncaj.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel Alternativa=new JPanel();
                Alternativa.setLayout(new GridLayout(1,5));
                JTextField PODparam_naziv=new JTextField();

                JLabel naziv=new JLabel("podparametri naziv");
                Alternativa.add(naziv);
                Alternativa.add(PODparam_naziv);

                JTextField PODparam_utez=new JTextField();
                JLabel utez=new JLabel("PODparam_utez");
                Alternativa.add(utez);
                Alternativa.add(PODparam_utez);

                JTextField PODmin=new JTextField();
                JLabel min=new JLabel("min");
                Alternativa.add(min);
                Alternativa.add(PODmin);

                JTextField PODmax=new JTextField();
                JLabel max=new JLabel("max");
                Alternativa.add(max);
                Alternativa.add(PODmax);

                JList<Parameter> funkcija=new JList<>();
                DefaultListModel<parametri> f2 = new DefaultListModel<>();
                for(int i=0;i< poljeParameter.size();i++){
                    f2.addElement(poljeParameter.get(i));
                }

                JList<parametri> list2 = new JList<>(f2);
                JLabel funk=new JLabel("funkcija");

                JList<Funkcija> funkcijautezi=new JList<Funkcija>();
                DefaultListModel<Funkcija> f3 = new DefaultListModel<>();
               f3.add(1, Funkcija.LINEARNA);
                f3.add(2, Funkcija.EKSPONENTNA);
                f3.add(3, Funkcija.LOG);

                JList<parametri> list3 = new JList<>(f2);
                JLabel funkzd=new JLabel("funkcija");
JButton PodPKonec=new JButton();
                JButton PodPDodaj=new JButton();
                PodPDodaj.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                         int zbrani=list2.getSelectedIndex();
                         int utez=Integer.parseInt(PODparam_utez.getText());
                         int min=Integer.parseInt(PODmin.getText());
                                 int max=Integer.parseInt(PODmax.getText());
                         poljeParameter.get(zbrani).setPodrednni(new podParametri(utez,PODparam_naziv.getText(),min,max,Funkcija.LINEARNA));
                        poljePODParameter.add(new podParametri(utez,PODparam_naziv.getText(),min,max,Funkcija.LINEARNA));

                        countPP[0]++;
                   System.out.println(countPP[0]);
                    }
                });
PodPKonec.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        JPanel Alternativa=new JPanel();
        Alternativa.setLayout(new GridLayout(1,countPP[0]+2));
        JTextField ALTERNATIVAmaut=new JTextField();


        JTextField a1=new JTextField();
        JTextField a2=new JTextField();
        JTextField a3=new JTextField();
        JTextField a4=new JTextField();
        JTextField a5=new JTextField();
        JTextField a6=new JTextField();
        JTextField a7=new JTextField();
        JTextField a8=new JTextField();
        JTextField a9=new JTextField();
        JTextField a10=new JTextField();

        JButton dodaj_alternativo=new JButton("Dodaj alternativo");
        Alternativa.add(dodaj_alternativo);
        Alternativa.add(ALTERNATIVAmaut);
        tab.addTab("Alternative",Alternativa);


        for (int i=0;i<countPP[0];i++){

            //Alternativa.add(new JLabel(poljeParameter.get(i).naziv));
            if(i==0) {
                Alternativa.add(a1);
            }
            if(i==1) {
                Alternativa.add(a2);
            }
            if(i==2) {
                Alternativa.add(a3);
            } if(i==3) {
                Alternativa.add(a4);
            } if(i==4) {
                Alternativa.add(a5);
            }
            if(i==5) {
                Alternativa.add(a6);
            }
            if(i==6) {
                Alternativa.add(a7);
            }
            if(i==7) {
                Alternativa.add(a8);
            } if(i==8) {
                Alternativa.add(a9);
            } if(i==9) {
                Alternativa.add(a10);
            }


            final int[] count = {0};

            int[] countAA= {0};

            dodaj_alternativo.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    String ime = ALTERNATIVAmaut.getText();

                    int vrednost = Integer.parseInt(a1.getText());
                    poljeAlternativa.add(new Alternativa(ime,poljeParameter.size()));

                    // poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                    //  System.out.println("tu sm");
                    int idfk =poljeParameter.size();

                    System.out.println(idfk);
                    if(idfk>0) {
                        vrednost = Integer.parseInt(a1.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);

                    }
                    if(idfk>1) {
                        vrednost = Integer.parseInt(a2.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);

                    }
                    if(idfk>2) {
                        vrednost = Integer.parseInt(a3.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);

                    }
                    if(idfk>3) {
                        vrednost = Integer.parseInt(a4.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);

                    }
                    if(idfk>4) {
                        vrednost = Integer.parseInt(a5.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                    }
                    if(idfk>5) {
                        vrednost = Integer.parseInt(a6.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                    }
                    if(idfk>6) {
                        vrednost = Integer.parseInt(a7.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                    }
                    if(idfk>7) {
                        vrednost = Integer.parseInt(a8.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                    }
                    if(idfk>8) {
                        vrednost = Integer.parseInt(a9.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                    }
                    if(idfk>9) {
                        vrednost = Integer.parseInt(a10.getText());
                        poljeAlternativa.get(count[0]).setVrednosti(vrednost);
                    }


                    count[0]++;
                    System.out.println("izpis counta         "+ count[0]);
                }



            });

        }
        Alternativa.add(koncaj);
koncaj.addActionListener(new
                                 ActionListener() {
                                     @Override
                                     public void actionPerformed(ActionEvent e) {


                                         JPanel konc=new JPanel();
                                         konc.setLayout(new GridLayout(1,1));

JButton finish=new JButton();
konc.add(finish);
finish.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {


        JPanel konc=new JPanel();
        konc.setLayout(new GridLayout(1,1));
        JTextArea izpis=new JTextArea();
        String naz=poljePODParameter.get(0).getNaziv();
        izpis.append(naz);
        for(int i=0;i<poljePODParameter.size();i++){
            if(naz!=poljePODParameter.get(i).getNaziv()){
            izpis.append(poljePODParameter.get(i).getNaziv() );
            izpis.append("              ");
            naz=poljePODParameter.get(i).getNaziv();
        }
        }
        int center = poljeAlternativa.size() / 2;
//Remove the half

        izpis.append("\n");
        for(int i=0;i<poljeAlternativa.size();i++){
            izpis.append(poljeAlternativa.get(i).getAlternativa_naziv());
            izpis.append("              ");

                izpis.append(Arrays.toString(poljeAlternativa.get(i).getVrednosti()));
                izpis.append("              ");



            izpis.append("\n");
        }

        //---------------------------------------------------------------------------------------izpis najbolse
        izpis.append("\n");

        //izpis.append("skupne vrednosti: ");
        float[] vrednotenje=new float[poljeAlternativa.size()];
        for(int i=0;i<poljePODParameter.size();i++){
            float vmesna=0;
            float funk=0;
            for(int n=0;n<poljePODParameter.size()-1;n++){
                 funk=  ((poljePODParameter.get(n).funkcija(poljePODParameter.get(n).getMin(),poljePODParameter.get(n).getMax(),poljePODParameter.get(n).getFz(),poljeAlternativa.get(n).getVrednosti()[i])))+(float) Math.random();
                funk=funk/10;
                System.out.println(funk);
                vrednotenje[i]=funk;
            }

        }
        System.out.println(vrednotenje.length);
        System.out.println();
        for (int i=0;i< vrednotenje.length;i++){
            if(vrednotenje[i]!=0){
                System.out.println(vrednotenje[i]);
                //izpis.append(String.valueOf(vrednotenje[i])+"              ");
            }}

        izpis.append("izbira najbolse vrednosti: ");
        float najbolsa=0;
        DefaultPieDataset pieDataset = new DefaultPieDataset();
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int i=0;i< vrednotenje.length;i++){


            if(vrednotenje[i]!=0){
                System.out.println(vrednotenje[i]);

                dataset.setValue(((int) (vrednotenje[i]*100)), "Profit", i+". Alternativa");
                if(vrednotenje[i]>najbolsa){
                    najbolsa=vrednotenje[i];
                }
            }}



        JFreeChart chart = ChartFactory.createBarChart("MAUT",
                "Alternativa", "Vrednost", dataset, PlotOrientation.VERTICAL,
                false, true, false);

        try {
            ChartUtilities.saveChartAsJPEG(new File("C:\\chart.jpg"), chart, 500, 300);
        } catch (IOException w) {
            System.err.println("Problem occurred creating chart.");
        }


        pieDataset.setValue(". Alternativa", 1);
        pieDataset.setValue(". Alternativa", 2);
        pieDataset.setValue(". Alternativa", 3);

        izpis.append(String.valueOf(najbolsa));


        for (int i=0;i< vrednotenje.length;i++){


            }


/*
        JFreeChart chartbar = ChartFactory.createBarChart
                ("Chart ker more bit", // Title
                        dataset, // Dataset
                        true, // Show legend
                        true, // Use tooltips
                        false // Configure chart to generate URLs?
                );
        try {
            ChartUtilities.saveChartAsJPEG(new File("C:\\chart.jpg"), chart, 5000, 3000);
        } catch (Exception ppp) {
            System.out.println("Problem occurred creating chart.");
        }*/


        ChartPanel ccc=new ChartPanel(chart);
JPanel panel=new JPanel();
panel.add(ccc);
tab.add(panel);
        konc.add(izpis);

        tab.add(konc);
    }
});


                                         tab.add(konc);
                                     }
                                 });





    }
});



                Alternativa.add(funk);
                Alternativa.add(funkcija);
                Alternativa.add(list2);
                PodPDodaj.setLabel("Dodaj");
                PodPKonec.setLabel("Konec");
                Alternativa.add(PodPDodaj);
                Alternativa.add(PodPKonec);

                tab.add("PODPARAMETRI",Alternativa);
            }
        });

/*
        JPanel zd= new JPanel();
        zd.setLayout(new GridLayout(2,1));

        JButton button=new JButton("Analiza");





        zd.add(list2);
        zd.add(button);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int z= list2.getSelectedIndex();
                JPanel graf =new JPanel();
*/





tab.add(Parametri);
                frame.add(tab);




        }
    }
