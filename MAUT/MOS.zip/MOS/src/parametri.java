
//maut


public class parametri {
    public int getUtez() {
        return utez;
    }

    public void setUtez(int utez) {
        this.utez = utez;
    }

    public int utez;

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public  String naziv;

    public parametri getNadredni() {
        return nadredni;
    }

    public void setNadredni(parametri nadredni) {
        this.nadredni = nadredni;
    }

    public podParametri[] getPodrednni() {
        return podrednni;
    }

    public void setPodrednni(podParametri podrednni) {
        for(int i=0;i<4;i++){
            if(this.podrednni[i]==null){
                this.podrednni[i] = podrednni;
                break;
            }
        }

    }

    public parametri nadredni;

    public parametri(int utez, String naziv) {
        this.utez = utez;
        this.naziv = naziv;

        podrednni= new podParametri[]{null,null,null,null};
    }

    public podParametri[] podrednni;
}
