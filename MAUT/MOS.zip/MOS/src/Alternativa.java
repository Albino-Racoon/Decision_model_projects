import java.util.Arrays;

public class Alternativa {
    public String Alternativa_naziv;

    public int[] getVrednosti() {
        return vrednosti;
    }

    public void setVrednosti(int vrednost) {
        for(int i=0;i<vrednosti.length;i++){
            if(vrednosti[i]==0){
                vrednosti[i]=vrednost;
                break;
            }
        }

    }

    public int[] vrednosti;

    public Alternativa(String alternativa_naziv, int vr) {
        this.Alternativa_naziv = alternativa_naziv;

       int[] pomozni_array=new int[vr];
        for (int i=0;i<pomozni_array.length;i++){
            pomozni_array[i]=0;
        }
        this.vrednosti=pomozni_array;
    }

    public String getAlternativa_naziv() {
        return Alternativa_naziv;
    }

    public void setAlternativa_naziv(String alternativa_naziv) {
        Alternativa_naziv = alternativa_naziv;
    }

    @Override
    public String toString() {
        return "Alternativa{" +
                "Alternativa_naziv='" + Alternativa_naziv + '\'' +
                ", vrednosti=" + Arrays.toString(vrednosti) +
                '}';
    }
}
