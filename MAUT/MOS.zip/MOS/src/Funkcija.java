public enum Funkcija {
    LINEARNA, EKSPONENTNA, LOG
}
