public class Parameter {
    public String naziv;
    public int utez;

    public Parameter(int utez, String naziv) {
        this.utez = utez;
        this.naziv=naziv;
    }


    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String toString() {
        return "Parameter{" +
                "naziv='" + naziv + '\'' +
                ", utez=" + utez +
                '}';
    }
}
